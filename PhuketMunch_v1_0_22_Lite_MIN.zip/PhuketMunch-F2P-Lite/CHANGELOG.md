# Phuket Munch F2P — Changelog

## 1.0.14 — Welcome hide fix, button spacing, English UI
**Type:** Patch + Minor
- Fixed: Welcome screen now always hides when clicking "Sawasdee" (no race conditions).
- UI: Moved "Sawasdee" button slightly lower for better spacing.
- Language: Entire UI switched to English (labels, dialogs, buttons).
- Lite: full code, no assets. Place your PNG/MP3 locally under assets/.

## 1.0.15 — Fix: welcome overlay hide
- Added missing `.hidden{display:none}`.
- Hardened `hide()/show()` to also set `style.display`.

## 1.0.16 — Music autoplay (Electron) + +50% object scale
- Electron: `app.commandLine.appendSwitch('autoplay-policy','no-user-gesture-required')` to allow music without user gesture.
- Kept intro retry-on-click safeguard.
- Increased sizes by ~50%: player, ghosts, coconuts, mango, durian, Red Bull, palms. Background unchanged.

## 1.0.17 — Left/Right vehicle only, quieter frightened, much rarer specials
- Player vehicle now flips only left/right; no full rotation.
- Frightened SFX volume reduced significantly.
- Special items (Mango, Red Bull, Durian) spawn much more rarely.

## 1.0.18 — Welcome polish + intro music
- Button changed to "Sawasdee Na" and welcome fades out into vehicle selection.
- Title shown only on the welcome screen.
- Subtle wavy background animation on welcome.
- Intro music starts on launch; retry on first click if blocked.
- Audio balance: music louder (1.0) vs SFX (0.5).

## 1.0.19 — Instructions screen (minimal)
- Added post-welcome **Instructions** overlay with Big Buddha guide and final game text.
- Flow: Welcome → Instructions → Vehicle. No other gameplay changes.

## 1.0.21 — Coconut count scaling (MIN)
- Level 1 now starts with 6 coconuts.
- Each next level adds +4 coconuts.
- Kept vehicle click-to-start and bounce from 1.0.20.

## 1.0.22 — Smarter Naga AI + no overlapping (MIN)
- Naga spirits now pursue the player with simple pathing and slight randomness.
- Ghosts avoid overlapping using separation and avoid stepping into each other's space.
